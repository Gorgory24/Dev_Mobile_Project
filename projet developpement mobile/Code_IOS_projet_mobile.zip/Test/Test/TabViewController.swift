//
//  TabViewController.swift
//  Test
//
//  Created by etudiant on 09/04/2019.
//  Copyright © 2019 etudiant. All rights reserved.
//

import SpriteKit
import GameplayKit
import CoreMotion
import CoreData
import UIKit

class TabViewController: UITableViewController,NSFetchedResultsControllerDelegate{
    
    var arr : [String] = []

    @IBOutlet weak var Save: UIButton!
    @IBOutlet var table: UITableView!
    @IBOutlet weak var DeleteName: UITextField!
    
    //Bouton de suppression de score via le nom
    //Ecrasement des anciennes données
    
    @IBAction func DeleteName(_ sender: UIButton) {
       let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Users")
        request.returnsObjectsAsFaults = false
        let sortDescriptor = NSSortDescriptor(key:"score",ascending: false)
        request.sortDescriptors = [sortDescriptor]
        
        let fetchrequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        fetchrequest.predicate = NSPredicate(format:"name=%@",DeleteName.text!)
        
        
        do{
            let test = try context.fetch(fetchrequest)
            let object = test[0] as! NSManagedObject
            context.delete(object)
            do{
                try context.save()
            }catch{
                print(error)
            }
            
        }catch{
            print(error)
        }
    }
    
    //-----GESTION DE LA TABVIEW----
    // Création de la cellule avec pour données
    //les informations de la base
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        let text = arr[indexPath.row]
        cell?.textLabel?.text = text
        return cell!
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    //Chargement des données de la base dans le tableau arr
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Users")
        request.returnsObjectsAsFaults = false
        let sortDescriptor = NSSortDescriptor(key:"score",ascending: false)
        request.sortDescriptors = [sortDescriptor]
        
        do{
            let results = try context.fetch(request)
            if results.count > 0 {
                for r in results as![NSManagedObject]{
                    if let userDate = r.value(forKey: "date") as? Date , let userName = r.value(forKey: "name") as? String,let userScore = r.value(forKey: "score") as? Int{
                        arr.append("Name:\(userName)," + "Score:\(userScore)" + ",Date: \(userDate)")
                    }
                }
            }
        }catch{

        }
        table.dataSource = self
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Orientation écran
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .landscape
        } else {
            return .allButUpsideDown
        }
    }
    override func willTransition(to newCollection: UITraitCollection, with coordinator: UIViewControllerTransitionCoordinator) {
        if UIApplication.shared.statusBarOrientation.isLandscape{}
        else {}
    }
}
