//
//  PageSaveViewController.swift
//  Test
//
//  Created by etudiant on 08/04/2019.
//  Copyright © 2019 etudiant. All rights reserved.
//

import SpriteKit
import GameplayKit
import CoreMotion
import CoreData

class PageSaveViewController: UIViewController,UITextFieldDelegate {

    //Déclaration des composants de la view
    
    @IBOutlet weak var BoutonSave: UIButton!
    @IBOutlet weak var TextField: UITextField!
    
    //Variable ayant la valeur du score du joueur`
    
    var score:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //Sauvegarde des données, envoie dans la CORE DATA
    
    @IBAction func SendData(_ sender: UIButton) {

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
        
        newUser.setValue(Date(), forKey: "date")
        newUser.setValue(TextField.text, forKey: "name")
        newUser.setValue(score, forKey: "score")
        
        do{
            try context.save()
            
        }catch{

        }
    }
    
    /*********************************
     * Protocole UITextFieldDelegate *
     *********************************/
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
            
        } else {
            return .all
        }
    }
}
