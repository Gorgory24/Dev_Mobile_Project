//
//  GameScene.swift
//  Test
//
//  Created by etudiant on 25/03/2019.
//  Copyright © 2019 etudiant. All rights reserved.
//

import SpriteKit
import GameplayKit
import CoreMotion
import CoreData

class GameScene: SKScene , SKPhysicsContactDelegate  {

    var entities = [GKEntity]()
    var graphs = [String : GKGraph]()
    
    private var lastUpdateTime : TimeInterval = 0
    private var spinnyNode : SKShapeNode?
    
    //Récupération taille écran
    let w = UIScreen.main.bounds.width
    let h = UIScreen.main.bounds.height
    
    //Background
    var background = SKSpriteNode(imageNamed: "background")
    
    //Player
    var player :SKSpriteNode!
    
    //Obstacle
    var Obstacle : SKSpriteNode!
    
    //Location Player
    var locX = CGFloat()
    var locY = CGFloat()
    
    //Score
    var scoreLabel:SKLabelNode!
    var score : Int = 0
    static var ScoreUpdate : Int = 0
    //Vie
    var vieLabel:SKLabelNode!
    var viescore : Int = 4
    static var vieUpdate:Int = 0
    
    //Variable pour la génération de météor
    var SpawnTimer:Timer!

    
    var TestCollision:Bool = false
    
    //Tableau nom meteor
    var MyMeteor = ["Meteor0","Meteor1","Meteor2","Meteor3","Meteor4","Meteor5"]
    
    //Categorie Collision
    enum CategoryMask:UInt32{
        case CategoryPlayer = 0b01
        case CategoryMeteor = 0b10
        case CategoryLimit  = 0b11
    }
    var GameViewControllerDelegate:GameViewControllerDelegate?
    
    override func didMove(to view: SKView) {
        
        //Configuration de la physique du jeux
        self.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        self.physicsWorld.contactDelegate = self
        
        //background
        background.zPosition = 0
        background.position = CGPoint(x:0, y: 0)
        addChild(background)
        
        //Création du personnage
        player = SKSpriteNode(imageNamed :"VP.png")
        player.position = CGPoint(x:0,y:-h+200)
        player.name = "player"
        player.zPosition = 1
        player.physicsBody = SKPhysicsBody(circleOfRadius: player.size.width / 2)
        player.physicsBody?.usesPreciseCollisionDetection = true
        player.physicsBody?.affectedByGravity = false
        player.physicsBody?.isDynamic = false
        player.physicsBody?.categoryBitMask = CategoryMask.CategoryPlayer.rawValue
        player.physicsBody?.collisionBitMask = CategoryMask.CategoryMeteor.rawValue
        player.physicsBody?.contactTestBitMask = CategoryMask.CategoryMeteor.rawValue
        self.addChild(player)
        
        //Création Obstacle via un générateur SpawnTimer
        //Initilisation des paramettres du méteor

        SpawnTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            self.MyMeteor = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: self.MyMeteor) as! [String]
            self.Obstacle = SKSpriteNode(imageNamed :self.MyMeteor[0])
            self.Obstacle.name = self.MyMeteor[0]
            self.Obstacle.zPosition = 1
            self.Obstacle.size = CGSize(width:120.0,height:120.0)
            let PosXYRand = GKRandomDistribution(lowestValue: Int(-self.w + self.Obstacle.size.width), highestValue: Int(self.w - self.Obstacle.size.width))
            let position = CGFloat(PosXYRand.nextInt())
            let P :CGPoint = CGPoint(x:position, y: self.h+20)
            self.Obstacle.position = P
            self.addChild(self.Obstacle)
            self.Obstacle.physicsBody = SKPhysicsBody(circleOfRadius: self.Obstacle.size.width / 2)
            self.Obstacle.physicsBody?.usesPreciseCollisionDetection = true
            self.Obstacle.physicsBody?.categoryBitMask = CategoryMask.CategoryMeteor.rawValue
            self.Obstacle.physicsBody?.collisionBitMask = CategoryMask.CategoryPlayer.rawValue | CategoryMask.CategoryLimit.rawValue
            self.Obstacle.physicsBody?.contactTestBitMask = CategoryMask.CategoryPlayer.rawValue | CategoryMask.CategoryLimit.rawValue
            
            let AnimationDuration:TimeInterval = 4
            var actionArray = [SKAction]()
            actionArray.append(SKAction.move(to: CGPoint(x:position,y:-self.h-100), duration: AnimationDuration))
            
            //Si dépacement de l'écran delete l'objet
            if(self.Obstacle.position.y >= self.h){
                actionArray.append(SKAction.removeFromParent())
            }
            if(self.TestCollision){
                self.TestCollision = false
                actionArray.append(SKAction.removeFromParent())
            }
            else{
                self.score += 5
            }
            self.Obstacle.run(SKAction.sequence(actionArray))
        }
        
        //Configuration du Label Score
        scoreLabel = SKLabelNode()
        scoreLabel.zPosition = 1
        scoreLabel.text = "Score : \(score)"
        scoreLabel.position = CGPoint(x: w-150, y: h-100)
        scoreLabel.fontName = "Arial"
        scoreLabel.fontSize = 36
        scoreLabel.fontColor = UIColor.yellow
        self.addChild(scoreLabel)
    
        //Configuration du Label Vie
        vieLabel = SKLabelNode()
        vieLabel.zPosition = 1
        vieLabel.text = "Vie : \(viescore)"
        vieLabel.position = CGPoint(x: -w+150, y: h-100)
        vieLabel.fontName = "Arial"
        vieLabel.fontSize = 36
        vieLabel.fontColor = UIColor.yellow
        self.addChild(vieLabel)
        
    }
    
    //Détection tactile sur l'écran , gestion mouvement
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if(viescore != 0){
            for t in touches{
                locX = t.location(in: self).x
                locY = t.location(in: self).y
                }
            }
    }
    
    
    //Gestion de la collision de node
    
    func didBegin(_ contact: SKPhysicsContact) {
        if contact.bodyA.node?.name == "player" || contact.bodyB.node?.name == "Meteor0" || contact.bodyB.node?.name == "Meteor1" || contact.bodyB.node?.name == "Meteor2" || contact.bodyB.node?.name == "Meteor3" || contact.bodyB.node?.name == "Meteor4" || contact.bodyB.node?.name == "Meteor5"{
            // execute code to respond to object hitting player
            if(viescore != 0){
                TestCollision = true
                viescore -= 1
            }
            if(viescore == 0){
                SpawnTimer.invalidate()
                GameViewControllerDelegate?.GetScore(val: GameScene.ScoreUpdate)
                GameViewControllerDelegate?.GetVie(val: viescore)
            }
            
        }
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        // Update entities
        for entity in self.entities {
            entity.update(deltaTime: dt)
        }
        self.lastUpdateTime = currentTime

        
        //Mise a jours des labels score et vie
        scoreLabel.text = "Score :\(score)"
        vieLabel.text = "Vie :\(viescore)"
        
        //Affectation variable static globale pour récupération
        //de données via une autre class
        
        GameScene.ScoreUpdate = score
        
        //Déplacement du joueur en fonction des axeX touché sur l'écran
        
        if(locX > 0){
            if(player.position.x > w-89){player.position.x += 0 }
            else{
                player.position.x += 10
            }
        }else if (locX < 0){
            if(player.position.x < (-w + 89)){player.position.x += 0 }
            else{
                player.position.x -= 10
            }
        }
    }
}

//Protocol afin de récupérer les données passés
protocol GameViewControllerDelegate: class {
    func GetScore(val: Int)
    func GetVie(val: Int)
}
